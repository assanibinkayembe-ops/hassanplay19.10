# Sunset Session Edition 1 — Firebase Ticket System

This package is prepared for the existing HassanPlay GitHub Pages project.

## Ticket allocation
Firestore collection:
`tickets`

Expected documents:
`SSE1-0001` through `SSE1-0085`

Fields:
- serialNumber: String
- event: String = Sunset Session Edition 1
- status: String = available
- used: Boolean = false

After verified payment, the server-side allocation helper in `functions/index.js`
assigns the first available ticket transactionally and creates:
`https://assanibinkayembe-ops.github.io/hassanplay19.10/tickets/SSE1-XXXX.png`

## Important
Do not put M-PESA credentials, WhatsApp credentials, SMS credentials, or email
SMTP/API secrets in `index.html`. They must stay in Firebase Functions/server
environment variables or Secret Manager.

## Deployment
Upload the site files to the GitHub repository that serves:
https://assanibinkayembe-ops.github.io/hassanplay19.10/

Deploy Firebase Functions separately from the `functions` directory.
