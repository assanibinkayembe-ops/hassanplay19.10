# HassanPlay — Sunset Session Ticket System

This version keeps the current HassanPlay one-page site and adds:
- Sunset Session ticket purchase section
- Early Bird KSh 500 / Regular KSh 700
- M-PESA STK Push backend
- Firestore payment records
- Automatic unique ticket code after confirmed payment
- QR code generation in the browser
- WhatsApp ticket-sharing button

## Important
The frontend is static, so M-PESA credentials must NOT be placed in `index.html`.
The secure M-PESA API call belongs in Firebase Cloud Functions.

## Deployment outline
1. Create/select a Firebase project.
2. Enable Firestore and Cloud Functions.
3. Install Firebase CLI.
4. Put the `functions` folder and Firebase files in your project.
5. Configure the M-PESA variables from `.env.example` as secure server-side configuration.
6. Deploy functions.
7. Copy the deployed functions base URL into `FUNCTIONS_BASE` in `index.html`.
8. Host `index.html` on GitHub Pages.

## M-PESA
Start with the Safaricom Daraja sandbox, test STK Push and callbacks, then switch the backend base URL and credentials for production.

Do not commit real M-PESA consumer secrets or passkeys to GitHub.
