const {onRequest} = require("firebase-functions/v2/https");
const {setGlobalOptions} = require("firebase-functions");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");
const {initializeApp} = require("firebase-admin/app");
const crypto = require("crypto");

initializeApp();
setGlobalOptions({region:"us-central1",maxInstances:10});
const db=getFirestore();

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "*";
const MPESA_BASE_URL = process.env.MPESA_BASE_URL || "https://sandbox.safaricom.co.ke";
const MPESA_CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY;
const MPESA_CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET;
const MPESA_SHORTCODE = process.env.MPESA_SHORTCODE;
const MPESA_PASSKEY = process.env.MPESA_PASSKEY;
const MPESA_CALLBACK_URL = process.env.MPESA_CALLBACK_URL;

function cors(req,res){
  res.set("Access-Control-Allow-Origin",ALLOWED_ORIGIN);
  res.set("Access-Control-Allow-Headers","Content-Type");
  res.set("Access-Control-Allow-Methods","POST,OPTIONS");
  if(req.method==="OPTIONS"){res.status(204).send("");return true}
  return false;
}
function jsonError(res,msg,code=400){return res.status(code).json({error:msg})}
function normalizePhone(v){
  let p=String(v||"").replace(/\s+/g,"");
  if(p.startsWith("+254"))p="254"+p.slice(4);
  if(p.startsWith("07")||p.startsWith("01"))p="254"+p.slice(1);
  return p;
}
function ticketCode(){return "SS26-"+crypto.randomBytes(4).toString("hex").toUpperCase()}

async function accessToken(){
  const auth=Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString("base64");
  const r=await fetch(`${MPESA_BASE_URL}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${auth}`}});
  const d=await r.json(); if(!r.ok||!d.access_token) throw new Error("Unable to get M-PESA access token");
  return d.access_token;
}

exports.createPayment=onRequest(async(req,res)=>{
  if(cors(req,res))return;
  try{
    if(req.method!=="POST")return jsonError(res,"POST only",405);
    const {name,email,ticketType}=req.body||{};
    const phone=normalizePhone(req.body?.phone);
    const prices={earlybird:500,regular:700};
    if(!name||!phone||!prices[ticketType])return jsonError(res,"Missing or invalid ticket details");
    if(!/^254(7|1)\d{8}$/.test(phone))return jsonError(res,"Enter a valid Kenyan M-PESA number");
    if(!MPESA_CONSUMER_KEY||!MPESA_CONSUMER_SECRET||!MPESA_SHORTCODE||!MPESA_PASSKEY||!MPESA_CALLBACK_URL)
      return jsonError(res,"Payment backend is not configured",500);

    const amount=prices[ticketType];
    const paymentRef="SS-"+Date.now()+"-"+crypto.randomBytes(3).toString("hex").toUpperCase();
    const ref=await db.collection("payments").add({name,email:email||"",phone,ticketType,amount,paymentRef,status:"PENDING",createdAt:FieldValue.serverTimestamp()});
    const token=await accessToken();
    const now=new Date();
    const timestamp=now.toISOString().replace(/\D/g,"").slice(0,14);
    const password=Buffer.from(`${MPESA_SHORTCODE}${MPESA_PASSKEY}${timestamp}`).toString("base64");
    const payload={
      BusinessShortCode:Number(MPESA_SHORTCODE),Password:password,Timestamp:timestamp,
      TransactionType:"CustomerPayBillOnline",Amount:amount,PartyA:Number(phone),
      PartyB:Number(MPESA_SHORTCODE),PhoneNumber:Number(phone),CallBackURL:MPESA_CALLBACK_URL,
      AccountReference:paymentRef,TransactionDesc:"Sunset Session Ticket"
    };
    const r=await fetch(`${MPESA_BASE_URL}/mpesa/stkpush/v1/processrequest`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const d=await r.json();
    if(!r.ok||d.ResponseCode!=="0"){await ref.update({status:"FAILED",mpesaResponse:d});return jsonError(res,d.errorMessage||d.ResponseDescription||"M-PESA request failed",502)}
    await ref.update({checkoutRequestId:d.CheckoutRequestID,merchantRequestId:d.MerchantRequestID,mpesaResponse:d});
    return res.json({paymentId:ref.id,message:d.CustomerMessage||"STK push sent"});
  }catch(e){console.error(e);return jsonError(res,e.message||"Server error",500)}
});

exports.mpesaCallback=onRequest(async(req,res)=>{
  if(cors(req,res))return;
  try{
    const body=req.body||{};
    const cb=body.Body?.stkCallback;
    const checkoutId=cb?.CheckoutRequestID;
    if(!checkoutId)return res.json({ResultCode:0,ResultDesc:"Accepted"});
    const snap=await db.collection("payments").where("checkoutRequestId","==",checkoutId).limit(1).get();
    if(snap.empty)return res.json({ResultCode:0,ResultDesc:"Accepted"});
    const doc=snap.docs[0], data=doc.data();
    const resultCode=cb.ResultCode;
    if(resultCode===0){
      const items=cb.CallbackMetadata?.Item||[];
      const get=(name)=>items.find(x=>x.Name===name)?.Value;
      const ticket={ticketCode:ticketCode(),name:data.name,email:data.email||"",phone:data.phone,amount:data.amount,ticketType:data.ticketType,mpesaReceipt:get("MpesaReceiptNumber")||"",event:"Sunset Session",createdAt:FieldValue.serverTimestamp()};
      await db.collection("tickets").doc(ticket.ticketCode).set(ticket);
      await doc.ref.update({status:"PAID",ticketCode:ticket.ticketCode,mpesaReceipt:ticket.mpesaReceipt,paidAt:FieldValue.serverTimestamp()});
    }else{
      await doc.ref.update({status:"FAILED",resultCode,resultDesc:cb.ResultDesc||"Payment failed",updatedAt:FieldValue.serverTimestamp()});
    }
    return res.json({ResultCode:0,ResultDesc:"Accepted"});
  }catch(e){console.error(e);return res.json({ResultCode:0,ResultDesc:"Accepted"})}
});

exports.paymentStatus=onRequest(async(req,res)=>{
  if(cors(req,res))return;
  try{
    const id=req.body?.paymentId;if(!id)return jsonError(res,"paymentId required");
    const d=await db.collection("payments").doc(id).get();if(!d.exists)return jsonError(res,"Payment not found",404);
    const p=d.data();
    if(p.status==="PAID"&&p.ticketCode){
      const t=await db.collection("tickets").doc(p.ticketCode).get();
      return res.json({status:"PAID",ticket:{...t.data(),createdAt:undefined}});
    }
    return res.json({status:p.status||"PENDING"});
  }catch(e){return jsonError(res,e.message||"Server error",500)}
});